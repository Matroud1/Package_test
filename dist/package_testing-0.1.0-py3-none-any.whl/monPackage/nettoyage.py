def supprimer_na(df):
    return df.dropna()

def normaliser(df):
    return (df - df.mean()) / df.std()
