
def moyenne(liste):
    """Calcule la moyenne d'une liste de nombres"""
    return sum(liste) / len(liste) if liste else 0
