from monPackage import nettoyage, stats

__main__="__main__"
if __name__ == "__main__":
    print("Nettoyage des données...")
    nettoyage()
    print("Calcul des statistiques...")
    stats()
    print("Opérations terminées.")