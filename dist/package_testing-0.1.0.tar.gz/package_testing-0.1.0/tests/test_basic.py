
from monPackage.nettoyage import supprimer_na, normaliser
from monPackage.stats import moyenne
import pandas as pd


dataset=[1, 2, 3, 5, 8, None, 13, 21, None]
# conversion en DataFrame pour l'exemple
dataset_series = pd.Series(dataset)
def supprimer_na():
    assert supprimer_na(dataset_series) == [1, 2, 3, 5, 8, 13, 21]

def test_normaliser():
    assert normaliser(pd.Series([1, 2, 3])).tolist() == [-1.224744871391589, 0.0, 1.224744871391589]

def test_moyenne():
    assert moyenne([1, 2, 3]) == 2

def ecart_type():
    assert ecart_type([1, 2, 3, 4]) == 1.2909944487358056
