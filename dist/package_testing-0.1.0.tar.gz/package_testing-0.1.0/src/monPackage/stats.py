def moyenne(df):
    return df.mean()

def ecart_type(df):
    return df.std()